#!/usr/bin/env python3
"""
gate.py -- the one command contributors and agents run.

  python3 gate.py                    build, check, test (fast)
  python3 gate.py --full             also mutation-test the core
  python3 gate.py --write-results    regenerate results*.txt from real runs (implies --full)
  python3 gate.py --verify-results   regenerate and compare with the committed results (implies --full); exit 1 on any difference

Guards: every comparison asserts that both sides are non-empty, because an empty diff once looked like a pass.
"""
import re, subprocess, sys, time, pathlib

HERE = pathlib.Path(__file__).parent
PY = sys.executable

def run(args):
    r = subprocess.run([PY] + args, cwd=HERE, capture_output=True, text=True)
    return r.returncode, (r.stdout + r.stderr)

STEPS = [
    ("build registry", ["build_registry.py"]),
    ("check registry", ["check.py"]),
    ("build spec", ["build_spec.py"]),
    ("check spec (rules and mutation self-test)", ["check_spec.py"]),
    ("build plan data", ["build_plan.py"]),
    ("plan rules", ["plan.py", "--check"]),
    ("plan self-test and scenario contracts", ["plan.py", "--selftest"]),
    ("unit tests", ["-m", "unittest", "discover", "-s", "tests", "-t", "."]),
]
FULL = [("mutation testing of the core", ["tests/mutate.py"])]
WHATIFS = [
    ["--have", "none"],
    ["--have", "none,counsel", "--done", "V-04", "--assume", "A-05=fails"],
    ["--have", "none,dev,account,spend,entity,counsel,data,user", "--done", "V-01,V-02,V-03,V-04,V-05,V-06,D-01", "--assume", "A-01=fails,A-21=fails,A-04=fails"],
]

def tail(out):
    lines = [l for l in out.strip().splitlines() if l.strip()]
    keep = [l for l in lines if re.search(r"PLAN|SPEC:|INTEGRITY|^OK|^Ran|MUTATION|CONTRACTS|written|killed", l)]
    return (keep or lines or ["(no output)"])[-1][:110]

def strip_timing(text):
    return re.sub(r" in [0-9.]+s", "", text)

def results():
    out = {}
    out["results.txt"] = run(["check.py"])[1]
    out["results_spec.txt"] = run(["check_spec.py"])[1]
    plan = ["== plan rules ==", run(["plan.py", "--check"])[1], "== plan self-test and scenario contracts ==", run(["plan.py", "--selftest"])[1]]
    for w in WHATIFS:
        plan += ["== what-if: plan.py " + " ".join(w) + " ==", run(["plan.py"] + w)[1]]
    out["results_plan.txt"] = "\n".join(plan)
    ut = run(["-m", "unittest", "discover", "-s", "tests", "-t", ".", "-v"])[1]
    ut = "\n".join(l for l in ut.splitlines() if re.search(r"\.\.\. |^Ran |^OK|^FAILED", l))
    out["results_core.txt"] = "== unittest (verbose) ==\n" + strip_timing(ut) + "\n\n== mutation ==\n" + run(["tests/mutate.py"])[1]
    return out

def main():
    write, verify = "--write-results" in sys.argv, "--verify-results" in sys.argv
    full = "--full" in sys.argv or write or verify
    failed = []
    for name, args in STEPS + (FULL if full else []):
        t0 = time.time(); rc, out = run(args)
        print(f"  {'PASS' if rc == 0 else 'FAIL'}  {name:46} {time.time() - t0:5.1f}s  {tail(out)}")
        if rc != 0:
            failed.append(name); print("\n".join("        " + l for l in out.strip().splitlines()[-12:]))
    if failed:
        print(f"\nGATE: FAILED ({', '.join(failed)})"); sys.exit(1)
    if write or verify:
        res = results()
        for fn, text in res.items():
            if not text.strip(): print(f"  FAIL  {fn} generated empty"); failed.append(fn); continue
            path = HERE / fn
            if write:
                path.write_text(text); print(f"  wrote {fn} ({len(text.splitlines())} lines)")
            else:
                old = path.read_text() if path.exists() else ""
                if not old.strip(): print(f"  FAIL  {fn} committed copy missing or empty"); failed.append(fn); continue
                norm = lambda t: strip_timing(re.sub(r"docs parts written.*\n?", "", t)).strip()
                same = norm(old) == norm(text)
                print(f"  {'match' if same else 'DIFFERS'}  {fn} ({len(text.splitlines())} lines)")
                if not same: failed.append(fn)
    print("\nGATE: " + ("FAILED (" + ", ".join(failed) + ")" if failed else "PASSED"))
    sys.exit(1 if failed else 0)

if __name__ == "__main__":
    main()
